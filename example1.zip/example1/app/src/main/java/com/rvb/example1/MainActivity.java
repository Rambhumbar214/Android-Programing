// Package name of the application
package com.rvb.example1;

// Import AppCompatActivity class
import androidx.appcompat.app.AppCompatActivity;

// Import Bundle class
import android.os.Bundle;

// Import Log class for debugging messages
import android.util.Log;

// MainActivity class extending AppCompatActivity
public class MainActivity extends AppCompatActivity {

    // Tag name used for Logcat messages
    String tag = "Events";

    // Called when activity is created
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);              // Call parent method
        setContentView(R.layout.activity_main);          // Set layout
        Log.d(tag, "In onCreate() event");                // Log message
    }

    // Called when activity becomes visible
    @Override
    protected void onStart() {
        super.onStart();
        Log.d(tag, "In onStart() event");
    }

    // Called after activity is stopped, before restarting
    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(tag, "In onRestart() event");
    }

    // Called when activity starts interacting with user
    @Override
    protected void onResume() {
        super.onResume();
        Log.d(tag, "In onResume() event");
    }

    // Called when activity is partially hidden
    @Override
    protected void onPause() {
        super.onPause();
        Log.d(tag, "In onPause() event");
    }

    // Called when activity is no longer visible
    @Override
    protected void onStop() {
        super.onStop();
        Log.d(tag, "In onStop() event");
    }

    // Called before activity is destroyed
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(tag, "In onDestroy() event");
    }
}
