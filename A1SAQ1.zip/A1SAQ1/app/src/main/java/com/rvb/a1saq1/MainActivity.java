// Package name of the application
package com.rvb.a1saq1;

// Import Color class to change text color
import android.graphics.Color;

// Import Typeface class to change font family
import android.graphics.Typeface;

// Import Bundle for activity lifecycle
import android.os.Bundle;

// Import TypedValue to set text size in SP units
import android.util.TypedValue;

// Import Button UI component
import android.widget.Button;

// Import TextView UI component
import android.widget.TextView;

// Import AppCompatActivity as base class for activity
import androidx.appcompat.app.AppCompatActivity;

// MainActivity class which is the entry point of the app
public class MainActivity extends AppCompatActivity {

    // Declare TextView variable
    private TextView textView;

    // Variable to store current font size (20sp initially)
    private float currentSize = 20f;

    // Variable to track current color index
    private int colorIndex = 0;

    // Variable to track current font index
    private int fontIndex = 0;

    // onCreate method is called when activity is created
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        // Call parent class onCreate method
        super.onCreate(savedInstanceState);

        // Connect this activity with XML layout file
        setContentView(R.layout.activity_main);

        // Link TextView from XML using its ID
        textView = findViewById(R.id.textView);

        // Increase Font Size button click listener
        findViewById(R.id.btnIncrease).setOnClickListener(v -> {

            // Increase font size by 2sp
            currentSize += 2;

            // Apply increased font size to TextView
            textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, currentSize);
        });

        // Decrease Font Size button click listener
        findViewById(R.id.btnDecrease).setOnClickListener(v -> {

            // Decrease font size by 2sp
            currentSize -= 2;

            // Apply decreased font size to TextView
            textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, currentSize);
        });

        // Change Font Color button click listener
        findViewById(R.id.btnColor).setOnClickListener(v -> {

            // Create array of colors
            int[] colors = {
                    Color.RED,    // Red color
                    Color.BLUE,   // Blue color
                    Color.GREEN,  // Green color
                    Color.BLACK   // Black color
            };

            // Set text color using current color index
            textView.setTextColor(colors[colorIndex]);

            // Move to next color (loop back using modulus)
            colorIndex = (colorIndex + 1) % colors.length;
        });

        // Change Font Family button click listener
        findViewById(R.id.btnFont).setOnClickListener(v -> {

            // Create array of font families
            Typeface[] fonts = {
                    Typeface.DEFAULT,     // Default font
                    Typeface.SERIF,       // Serif font
                    Typeface.SANS_SERIF,  // Sans-serif font
                    Typeface.MONOSPACE    // Monospace font
            };

            // Apply selected font family to TextView
            textView.setTypeface(fonts[fontIndex]);

            // Move to next font family (loop back using modulus)
            fontIndex = (fontIndex + 1) % fonts.length;
        });
    }
}
