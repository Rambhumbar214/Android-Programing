package com.rvb.a2sbq2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    TextView tvFirstName, tvMiddleName, tvLastName, tvDOB, tvAddress, tvEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // Link XML views
        tvFirstName = findViewById(R.id.tvFirstName);
        tvMiddleName = findViewById(R.id.tvMiddleName);
        tvLastName = findViewById(R.id.tvLastName);
        tvDOB = findViewById(R.id.tvDOB);
        tvAddress = findViewById(R.id.tvAddress);
        tvEmail = findViewById(R.id.tvEmail);

        // Get data from intent
        String firstName = getIntent().getStringExtra("firstName");
        String middleName = getIntent().getStringExtra("middleName");
        String lastName = getIntent().getStringExtra("lastName");
        String dob = getIntent().getStringExtra("dob");
        String address = getIntent().getStringExtra("address");
        String email = getIntent().getStringExtra("email");

        // Set data to TextViews
        tvFirstName.setText("First Name: " + firstName);
        tvMiddleName.setText("Middle Name: " + middleName);
        tvLastName.setText("Last Name: " + lastName);
        tvDOB.setText("Date of Birth: " + dob);
        tvAddress.setText("Address: " + address);
        tvEmail.setText("Email: " + email);
    }
}
