package com.rvb.q2saq2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

// Second Activity: Displays the message
public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        // Link TextView from XML
        TextView tvMessage = findViewById(R.id.tvMessage);

        // Get message from Intent
        String message = getIntent().getStringExtra("message");

        // Set message to TextView
        tvMessage.setText(message);
    }
}