package com.rvb.q2saq2; // package name

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

// Main Activity: First screen
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Link button from XML
        Button btnSend = findViewById(R.id.btnSend);

        // Set click listener to send message
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Create an Intent to start SecondActivity
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);

                // Put message in Intent
                intent.putExtra("message", "Hello");

                // Start SecondActivity
                startActivity(intent);
            }
        });
    }
}
