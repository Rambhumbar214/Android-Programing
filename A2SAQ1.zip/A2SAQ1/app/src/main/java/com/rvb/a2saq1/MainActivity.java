package com.rvb.a2saq1;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

// Main activity class
public class MainActivity extends AppCompatActivity {

    // Tag for Logcat messages
    String tag = "ActivityEvents";

    // Called when the activity is first created
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(tag, "In onCreate() event");
    }

    // Called when activity becomes visible
    @Override
    protected void onStart() {
        super.onStart();
        Log.d(tag, "In onStart() event");
    }

    // Called when activity comes back to foreground after being stopped
    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(tag, "In onRestart() event");
    }

    // Called when activity starts interacting with user
    @Override
    protected void onResume() {
        super.onResume();
        Log.d(tag, "In onResume() event");
    }

    // Called when activity loses focus but is still visible
    @Override
    protected void onPause() {
        super.onPause();
        Log.d(tag, "In onPause() event");
    }

    // Called when activity is no longer visible
    @Override
    protected void onStop() {
        super.onStop();
        Log.d(tag, "In onStop() event");
    }

    // Called before activity is destroyed
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(tag, "In onDestroy() event");
    }
}
