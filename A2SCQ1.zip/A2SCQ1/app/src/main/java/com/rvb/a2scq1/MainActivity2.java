package com.rvb.a2scq1;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    TextView tvSummary;
    Button btnViewProfile;

    String name, age, email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        tvSummary = findViewById(R.id.tvSummary);
        btnViewProfile = findViewById(R.id.btnViewProfile);

        // Get data from first activity
        name = getIntent().getStringExtra("name");
        age = getIntent().getStringExtra("age");
        email = getIntent().getStringExtra("email");

        // Display brief summary
        tvSummary.setText("Name: " + name + "\nAge: " + age);

        // Button click to view full profile
        btnViewProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Pass data to third activity
                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                intent.putExtra("name", name);
                intent.putExtra("age", age);
                intent.putExtra("email", email);
                startActivity(intent);
            }
        });
    }
}
