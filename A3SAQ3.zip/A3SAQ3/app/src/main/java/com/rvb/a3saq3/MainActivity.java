package com.rvb.a3saq3;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText etInput;
    String input = "";
    String operator = "";
    double num1 = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etInput = findViewById(R.id.etInput);

        int[] numberButtons = {R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4, R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9};
        int[] operatorButtons = {R.id.btnPlus, R.id.btnMinus, R.id.btnMultiply, R.id.btnDivide};

        // Number buttons
        for (int id : numberButtons) {
            Button btn = findViewById(id);
            btn.setOnClickListener(v -> {
                input += ((Button)v).getText().toString();
                etInput.setText(input);
            });
        }

        // Operator buttons
        for (int id : operatorButtons) {
            Button btn = findViewById(id);
            btn.setOnClickListener(v -> {
                if (!input.isEmpty()) {
                    num1 = Double.parseDouble(input);
                    operator = ((Button)v).getText().toString();
                    input = "";
                    etInput.setText("");
                }
            });
        }

        // Equals button
        Button btnEquals = findViewById(R.id.btnEquals);
        btnEquals.setOnClickListener(v -> {
            if (!input.isEmpty()) {
                double num2 = Double.parseDouble(input);
                double result = 0;
                switch (operator) {
                    case "+": result = num1 + num2; break;
                    case "-": result = num1 - num2; break;
                    case "*": result = num1 * num2; break;
                    case "/":
                        if (num2 != 0) result = num1 / num2;
                        else {
                            etInput.setText("Error!");
                            return;
                        }
                        break;
                }
                etInput.setText(String.valueOf(result));
                input = "";
            }
        });

        // Dot button
        findViewById(R.id.btnDot).setOnClickListener(v -> {
            if (!input.contains(".")) {
                input += ".";
                etInput.setText(input);
            }
        });
    }
}
